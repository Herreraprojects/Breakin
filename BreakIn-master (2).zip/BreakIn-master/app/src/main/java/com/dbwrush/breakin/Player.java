package com.dbwrush.breakin;

import android.graphics.Point;
import android.graphics.RectF;

public class Player {
    private RectF rectangle;
    private float width, height, x, y, speed;
    private final int SCREEN_WIDTH, SCREEN_HEIGHT;
    public enum MovingState {
        STOPPED, LEFT, RIGHT
    }
    private MovingState paddleMoving = MovingState.STOPPED;

    public Player(Point p) {
        width = 120;
        height = 15;

        SCREEN_WIDTH = p.x;
        SCREEN_HEIGHT = p.y;

        resetPosition();

        rectangle = new RectF(x, y, x + width, y + height);
        speed = 300;
    }

    public void update(long fps) {
        if(paddleMoving == MovingState.LEFT) {
            x -= speed / fps;
        }
        if(paddleMoving == MovingState.RIGHT) {
            x += speed / fps;
        }

        if(x + width > SCREEN_WIDTH) {
            x = SCREEN_WIDTH - width;
        }
        if(x < 0) {
            x = 0;
        }

        rectangle.left = x;
        rectangle.right = x + width;

    }

    public void setMoving(MovingState movingState) {
        paddleMoving = movingState;
    }

    public RectF getRectangle() {
        return rectangle;
    }

    public float getCenter() {
        return x + (width / 2);
    }

    public void resetPosition() {
        x = SCREEN_WIDTH / 2;
        y = SCREEN_HEIGHT - 140;
    }
}
