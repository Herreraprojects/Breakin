package com.dbwrush.breakin;

import android.graphics.Point;

public class Ball {
    private float x, y;
    private int screenWidth, screenHeight;
    private float xSpeed, ySpeed;

    public Ball(Point p) {
        screenWidth = p.x;
        screenHeight = p.y;
        reset();
    }

    public void update(long fps) {
        x += xSpeed * fps;
        y += ySpeed * fps;

        if(x < 0) {
            xSpeed = Math.abs(xSpeed); //Make sure xSpeed is positive!
        }
        if(x > screenWidth) {
            xSpeed = -Math.abs(xSpeed); //Make sure xSpeed is negative!
        }
        if(y < 0) {
            ySpeed = 0.1f;//Make sure ySpeed is positive!
        }
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public void reverseYSpeed() {
        ySpeed = -ySpeed;
    }

    public void randomXSpeed() {
        xSpeed = (float)Math.random() * 0.1f - 0.05f;
    }

    public void reset() {
        x = screenWidth / 2;
        y = screenHeight - 200;
        randomXSpeed();
        ySpeed = -0.1f;
    }
}
