package com.dbwrush.breakin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ///Action to change name, switches to name change layout
        Button buttonNewGame = (Button) findViewById(R.id.btnNew);
        buttonNewGame.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openNewGame();
            }
        });

        Button buttonColors = (Button) findViewById(R.id.btnColors);
        buttonColors.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                openColors();
            }
        });

    }

    public void openNewGame()
    {
        Intent intent = new Intent(this, ChangeColorv3.class );
        startActivity(intent);
    }
    public void openColors()
    {
        Intent intent = new Intent(this, ChangeColorv3.class );
        startActivity(intent);
    }












}
