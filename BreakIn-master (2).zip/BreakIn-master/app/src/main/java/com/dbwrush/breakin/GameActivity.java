package com.dbwrush.breakin;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;

public class GameActivity extends Activity {
    BreakinView breakinView;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sharedPreferences = getPreferences(Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();


        Point p = new Point();
        getWindowManager().getDefaultDisplay().getSize(p);
        breakinView = new BreakinView(this, p);
        setContentView(breakinView);

    }

    @Override
    protected void onResume() {
        super.onResume();
        breakinView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        breakinView.pause();
    }

    public void saveHighscore(int highscore) {
        editor.putInt(getString(R.string.saved_highscore_key), highscore);
        editor.apply();
    }

    public int[] getColors() {
        int[] colors = new int[5];

        int defaultBackground = Color.argb(255, 128, 128, 255);
        int defaultBlock = Color.argb(255, 64, 128, 64);
        int defaultText = Color.argb(255, 255, 255, 255);
        int defaultPlayer = Color.argb(255, 255, 255, 255);
        int defaultBall = Color.argb(255, 255, 255, 255);

        colors[0] = sharedPreferences.getInt(String.valueOf(R.string.saved_color_background_key), defaultBackground);
        colors[1] = sharedPreferences.getInt(String.valueOf(R.string.saved_color_block_key), defaultBlock);
        colors[2] = sharedPreferences.getInt(String.valueOf(R.string.saved_color_text_key), defaultText);
        colors[3] = sharedPreferences.getInt(String.valueOf(R.string.saved_color_player_key), defaultPlayer);
        colors[4] = sharedPreferences.getInt(String.valueOf(R.string.saved_color_ball_key), defaultBall);

        return colors;
    }

    public int getHighscore() {
        return sharedPreferences.getInt(String.valueOf(R.string.saved_highscore_key), 0);
    }
}
