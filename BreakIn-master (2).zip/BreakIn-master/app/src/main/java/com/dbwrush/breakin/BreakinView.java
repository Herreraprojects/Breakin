package com.dbwrush.breakin;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;

public class BreakinView extends SurfaceView implements Runnable {
    Thread thread = null;
    SurfaceHolder holder;
    volatile boolean playing;
    boolean paused = true;
    Canvas canvas;
    Paint paint;
    int screenWidth;
    int screenHeight;

    long fps;
    private long frameTime;

    Player player;
    Ball ball;
    ArrayList<Block> blocks;

    int score;
    int lives = 3;

    Color backgroundColor;
    Color blockColor;
    Color textColor;
    Color playerColor;
    Color ballColor;

    GameActivity gameActivity;

    public BreakinView(Context context, Point p) {
        super(context);
        gameActivity = (GameActivity)context;

        score = gameActivity.getHighscore();

        holder = getHolder();
        paint = new Paint();
        screenWidth = p.x;
        screenHeight = p.y;
        player = new Player(p);
        ball = new Ball(p);
        blocks = new ArrayList<>();

        int[] colors= gameActivity.getColors();
        backgroundColor = Color.valueOf(colors[0]);
        blockColor = Color.valueOf(colors[1]);
        textColor = Color.valueOf(colors[2]);
        playerColor = Color.valueOf(colors[3]);
        ballColor = Color.valueOf(colors[4]);

        setup();
    }

    @Override
    public void run() {
        while (playing) {
            long startTime = System.currentTimeMillis();
            if(!paused) {
                update();
                collisionChecks();
            }
            draw();
            frameTime = System.currentTimeMillis() - startTime;
            if(frameTime >= 1) {
                fps = 1000 / frameTime;
            }
        }
    }

    private void collisionChecks() {
        ArrayList<Block> toRemove = new ArrayList<>();
        for(Block block : blocks) {
            if(block.getHitbox().contains(ball.getX(), ball.getY())) {
                toRemove.add(block);
                ball.randomXSpeed();
                ball.reverseYSpeed();
            }
        }
        for(Block block : toRemove) {
            blocks.remove(block);
            score += block.getScore();
        }
        if(player.getRectangle().contains(ball.getX(), ball.getY())) {
            ball.reverseYSpeed();
            ball.randomXSpeed();
        }

        if(ball.getY() > screenHeight) {
            lives--;
            ball.reset();
            player.resetPosition();
            paused = true;
        }
    }

    public void setup() {
        score = 0;
        lives = 3;

        //Adjust these values to change the size and number of bricks!
        int cols = 6;
        int rows = 16;

        int blockWidth = screenWidth / cols;
        int blockHeight = screenHeight / 20;

        for(int col = 0; col < cols; col++) {
            for(int row = 1; row < rows; row++) {
                int score = (rows - row) * 10;
                blocks.add(new Block(row, col, blockWidth, blockHeight, score));
            }
        }
        //Add extra col for even-numbered rows
        for(int row = 2; row < rows; row += 2) {
            int score = (rows - row) * 10;
            blocks.add(new Block(row, cols, blockWidth, blockHeight, score));
        }
    }

    public void update() {
        player.update(fps);
        ball.update(fps);

        if(lives <= 0 || blocks.size() <= 0) {
            paused = true;
            setup();
        }
    }

    public void draw() {
        if(holder.getSurface().isValid()) {
            canvas = holder.lockCanvas();
            canvas.drawColor(backgroundColor.toArgb());
            paint.setColor(playerColor.toArgb());
            canvas.drawRect(player.getRectangle(), paint);
            paint.setColor(ballColor.toArgb());
            canvas.drawCircle(ball.getX(), ball.getY(), 10f, paint);

            paint.setColor(blockColor.toArgb());
            for(Block block : blocks) {
                canvas.drawRect(block.getHitbox(), paint);
            }

            drawText();
            holder.unlockCanvasAndPost(canvas);
        }
    }

    public void drawText() {
        paint.setColor(textColor.toArgb());
        paint.setTextSize(50);
        canvas.drawText("Score: " + score, 10, 50, paint);
        canvas.drawText("Lives: " + lives, 10, 90, paint);
        if(blocks.size() == 0) {
            paint.setTextSize(100);
            canvas.drawText("A WINNER IS YOU", 10, screenHeight / 2, paint);
            gameActivity.saveHighscore(score);
        }
        if(lives <= 0) {
            paint.setTextSize(90);
            canvas.drawText("Lol. Get good.", 10, screenHeight/2, paint);
            gameActivity.saveHighscore(score);
        }
    }

    public void pause() {
        playing = false;
        try {
            thread.join();
        } catch (InterruptedException e) {
            Log.e("Error:", "At joining thread");
        }
    }

    public void resume() {
        playing = true;
        thread = new Thread(this);
        thread.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        switch (motionEvent.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                paused = false;
                if(motionEvent.getX() > player.getCenter()) {
                    player.setMoving(Player.MovingState.RIGHT);
                } else {
                    player.setMoving(Player.MovingState.LEFT);
                }
                break;
            case MotionEvent.ACTION_UP:
                player.setMoving(Player.MovingState.STOPPED);
                break;
        }
        return true;
    }
}
