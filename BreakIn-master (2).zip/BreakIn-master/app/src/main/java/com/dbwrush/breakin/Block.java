package com.dbwrush.breakin;

import android.graphics.RectF;

public class Block {
    private RectF hitbox;
    private int score;
    public Block(int row, int col, int width, int height, int score) {
        int pad = 1;
        int offset = 0;
        if(row % 2 == 0) {
            offset = width / 2;
        }
        this.score = score;
        hitbox = new RectF(col * width + pad - offset, row * height + pad, col * width + width - pad - offset, row * height + height - pad);
    }

    public RectF getHitbox() {
        return hitbox;
    }

    public int getScore() {
        return score;
    }
}
